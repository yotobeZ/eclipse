/*
 * Copyright (c) 2005 Jason Carreira. All Rights Reserved.
 */
package com.opensymphony.async.model;

import java.util.Date;

/**
 * Run
 *
 * @author Jason Carreira <jcarreira@eplus.com>
 */
public class Run extends AbstractDomainObject  {
    private Experiment experiment;
    private Date runDate = new Date();

    public Experiment getExperiment() {
        return experiment;
    }

    public void setExperiment(Experiment experiment) {
        this.experiment = experiment;
    }

    public Date getRunDate() {
        return runDate;
    }

    public void setRunDate(Date runDate) {
        this.runDate = runDate;
    }
}

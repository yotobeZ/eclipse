/*
 * Copyright (c) 2005 Jason Carreira. All Rights Reserved.
 */
package com.opensymphony.async.web.actions;

import java.util.List;

/**
 * ListExperiments
 *
 * @author Jason Carreira <jcarreira@eplus.com>
 */
public class ListExperiments extends AbstractExperimentAction {
    private List experiments;

    public List getExperiments() {
        return experiments;
    }

    public String execute() throws Exception {
        experiments = experimentDao.findAll();
        return SUCCESS;
    }
}

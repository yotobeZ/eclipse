/*
 * Copyright (c) 2005 Jason Carreira. All Rights Reserved.
 */
package com.opensymphony.async.web.actions;

import com.opensymphony.xwork.ActionSupport;
import com.opensymphony.async.model.ExperimentDao;

/**
 * AbstractExperimentAction
 *
 * @author Jason Carreira <jcarreira@eplus.com>
 */
public abstract class AbstractExperimentAction extends ActionSupport {
    protected ExperimentDao experimentDao;

    public void setExperimentDao(ExperimentDao experimentDao) {
        this.experimentDao = experimentDao;
    }
}

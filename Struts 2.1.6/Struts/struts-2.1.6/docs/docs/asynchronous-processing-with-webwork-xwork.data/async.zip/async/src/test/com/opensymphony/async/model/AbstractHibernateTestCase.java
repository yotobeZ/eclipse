/*
 * Copyright (c) 2005 Jason Carreira. All Rights Reserved.
 */
package com.opensymphony.async.model;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.test.AbstractTransactionalSpringContextTests;

/**
 * AbstractHibernateTestCase
 *
 * @author Jason Carreira <jcarreira@eplus.com>
 */
public abstract class AbstractHibernateTestCase extends AbstractTransactionalSpringContextTests {
    protected final Log log = LogFactory.getLog(this.getClass());
    
    protected String[] getConfigLocations() {
        return new String[] {"applicationContext.xml"};
    }

}
